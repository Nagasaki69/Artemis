﻿using Microsoft.AspNetCore.Mvc;

namespace Ica.Artemis.WebUI.ViewComponents
{
    public class ImportExcelViewComponent : ViewComponent
    {
        public IViewComponentResult Invoke(string importUri, string getTemplateUri, string onImportedSucceeded)
        {
            return View(new DefaultModel()
            {
                ImportUri = importUri,
                GetTemplateUri = getTemplateUri,
                OnImportedSucceeded = onImportedSucceeded
            });
        }
    }

}
