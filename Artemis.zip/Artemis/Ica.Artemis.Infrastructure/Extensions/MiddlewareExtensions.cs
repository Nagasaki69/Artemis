﻿using Microsoft.AspNetCore.Builder;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ica.Artemis.Infrastructure.Extensions
{
    internal static class MiddlewareExtensions
    {
        public static IApplicationBuilder UseMiddlewares(this IApplicationBuilder app)
        {
            //app.UseMiddleware<LocalizationCookiesMiddleware>();
            //app.UseMiddleware<ExceptionHandlerMiddleware>();
            return app;
        }
    }

}
