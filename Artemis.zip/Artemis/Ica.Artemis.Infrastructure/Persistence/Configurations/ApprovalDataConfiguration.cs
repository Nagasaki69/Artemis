﻿using Ica.Artemis.Domain.Entities.Workflow;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ica.Artemis.Infrastructure.Persistence.Configurations
{
    public class ApprovalDataonfiguration : IEntityTypeConfiguration<ApprovalData>
    {
        public void Configure(EntityTypeBuilder<ApprovalData> builder)
        {
            builder.HasKey(t => t.WorkflowId);
            builder.Property(t => t.WorkflowId)
                .HasMaxLength(50)
                .ValueGeneratedNever();
        }
    }

}
