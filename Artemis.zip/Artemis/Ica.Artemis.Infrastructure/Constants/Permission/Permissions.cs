﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Ica.Artemis.Infrastructure.Constants.Permission
{
    public static class Permissions
    {
        [DisplayName("OrgChart")]
        [Description("OrgChart Permissions")]
        public static class OrgChart
        {
            public const string View = "Permissions.OrgChart.View";
            public const string Search = "Permissions.OrgChart.Search";
            public const string Export = "Permissions.OrgChart.Export";
        }
        [DisplayName("AuditTrails")]
        [Description("AuditTrails Permissions")]
        public static class AuditTrails
        {
            public const string View = "Permissions.AuditTrails.View";
            public const string Search = "Permissions.AuditTrails.Search";
            public const string Export = "Permissions.AuditTrails.Export";
        }
        [DisplayName("Logs")]
        [Description("Logs Permissions")]
        public static class Logs
        {
            public const string View = "Permissions.Logs.View";
            public const string Search = "Permissions.Logs.Search";
            public const string Export = "Permissions.Logs.Export";
        }
        [DisplayName("Workflow")]
        [Description("Approval Permissions")]
        public static class Approval
        {
            public const string View = "Permissions.Approval.View";
            public const string Approve = "Permissions.Approval.Approve";
            public const string Histories = "Permissions.Approval.Histories";
            public const string Search = "Permissions.Approval.Search";
            public const string Export = "Permissions.Approval.Export";
        }

        [DisplayName("Products")]
        [Description("Products Permissions")]
        public static class Products
        {
            public const string View = "Permissions.Products.View";
            public const string Create = "Permissions.Products.Create";
            public const string Edit = "Permissions.Products.Edit";
            public const string Delete = "Permissions.Products.Delete";
            public const string Search = "Permissions.Products.Search";
            public const string Export = "Permissions.Products.Export";
            public const string Import = "Permissions.Products.Import";
        }
        [DisplayName("Invoices")]
        [Description("Invoices Permissions")]
        public static class Invoices
        {
            public const string View = "Permissions.Invoices.View";
            public const string Create = "Permissions.Invoices.Create";
            public const string Edit = "Permissions.Invoices.Edit";
            public const string Delete = "Permissions.Invoices.Delete";
            public const string Search = "Permissions.Invoices.Search";
            public const string Export = "Permissions.Invoices.Export";
            public const string Import = "Permissions.Invoices.Import";
            public const string Upload = "Permissions.Invoices.Upload";
        }
        [DisplayName("Customers")]
        [Description("Customers Permissions")]
        public static class Customers
        {
            public const string View = "Permissions.Customers.View";
            public const string Create = "Permissions.Customers.Create";
            public const string Edit = "Permissions.Customers.Edit";
            public const string Delete = "Permissions.Customers.Delete";
            public const string Search = "Permissions.Customers.Search";
            public const string Export = "Permissions.Customers.Export";
            public const string Import = "Permissions.Customers.Import";
        }

        [DisplayName("Categories")]
        [Description("Categories Permissions")]
        public static class Categories
        {
            public const string View = "Permissions.Categories.View";
            public const string Create = "Permissions.Categories.Create";
            public const string Edit = "Permissions.Categories.Edit";
            public const string Delete = "Permissions.Categories.Delete";
            public const string Search = "Permissions.Categories.Search";
            public const string Export = "Permissions.Categories.Export";
            public const string Import = "Permissions.Categories.Import";
        }

        [DisplayName("Documents")]
        [Description("Documents Permissions")]
        public static class Documents
        {
            public const string View = "Permissions.Documents.View";
            public const string Create = "Permissions.Documents.Create";
            public const string Edit = "Permissions.Documents.Edit";
            public const string Delete = "Permissions.Documents.Delete";
            public const string Search = "Permissions.Documents.Search";
            public const string Export = "Permissions.Documents.Export";
            public const string Import = "Permissions.Documents.Import";
            public const string Download = "Permissions.Documents.Download";
        }
        [DisplayName("DocumentTypes")]
        [Description("DocumentTypes Permissions")]
        public static class DocumentTypes
        {
            public const string View = "Permissions.DocumentTypes.View";
            public const string Create = "Permissions.DocumentTypes.Create";
            public const string Edit = "Permissions.DocumentTypes.Edit";
            public const string Delete = "Permissions.DocumentTypes.Delete";
            public const string Search = "Permissions.DocumentTypes.Search";
            public const string Export = "Permissions.Documents.Export";
            public const string Import = "Permissions.Categories.Import";
        }
        [DisplayName("Dictionaries")]
        [Description("Dictionaries Permissions")]
        public static class Dictionaries
        {
            public const string View = "Permissions.Dictionaries.View";
            public const string Create = "Permissions.Dictionaries.Create";
            public const string Edit = "Permissions.Dictionaries.Edit";
            public const string Delete = "Permissions.Dictionaries.Delete";
            public const string Search = "Permissions.Dictionaries.Search";
            public const string Export = "Permissions.Dictionaries.Export";
            public const string Import = "Permissions.Dictionaries.Import";
        }

        [DisplayName("Users")]
        [Description("Users Permissions")]
        public static class Users
        {
            public const string View = "Permissions.Users.View";
            public const string Create = "Permissions.Users.Create";
            public const string Edit = "Permissions.Users.Edit";
            public const string Delete = "Permissions.Users.Delete";
            public const string Search = "Permissions.Users.Search";
            public const string Import = "Permissions.Users.Import";
            public const string Export = "Permissions.Dictionaries.Export";
            public const string ManageRoles = "Permissions.Users.ManageRoles";
            public const string RestPassword = "Permissions.Users.RestPassword";
            public const string Active = "Permissions.Users.Active";
        }

        [DisplayName("Roles")]
        [Description("Roles Permissions")]
        public static class Roles
        {
            public const string View = "Permissions.Roles.View";
            public const string Create = "Permissions.Roles.Create";
            public const string Edit = "Permissions.Roles.Edit";
            public const string Delete = "Permissions.Roles.Delete";
            public const string Search = "Permissions.Roles.Search";
            public const string Export = "Permissions.Roles.Export";
            public const string Import = "Permissions.Roles.Import";
            public const string ManagePermissions = "Permissions.Roles.Permissions";
            public const string ManageNavigation = "Permissions.Roles.Navigation";
        }

        [DisplayName("Role Claims")]
        [Description("Role Claims Permissions")]
        public static class RoleClaims
        {
            public const string View = "Permissions.RoleClaims.View";
            public const string Create = "Permissions.RoleClaims.Create";
            public const string Edit = "Permissions.RoleClaims.Edit";
            public const string Delete = "Permissions.RoleClaims.Delete";
            public const string Search = "Permissions.RoleClaims.Search";
        }



        [DisplayName("Dashboards")]
        [Description("Dashboards Permissions")]
        public static class Dashboards
        {
            public const string View = "Permissions.Dashboards.View";
        }

        [DisplayName("Hangfire")]
        [Description("Hangfire Permissions")]
        public static class Hangfire
        {
            public const string View = "Permissions.Hangfire.View";
        }


        /// <summary>
        /// Returns a list of Permissions.
        /// </summary>
        /// <returns></returns>
        public static List<string> GetRegisteredPermissions()
        {
            var permissions = new List<string>();
            foreach (var prop in typeof(Permissions).GetNestedTypes().SelectMany(c => c.GetFields(BindingFlags.Public | BindingFlags.Static | BindingFlags.FlattenHierarchy)))
            {
                var propertyValue = prop.GetValue(null);
                if (propertyValue is not null)
                    permissions.Add(propertyValue.ToString());
            }
            return permissions;
        }


    }

}
