﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ica.Artemis.Infrastructure.Constants.ClaimTypes
{
    public static class ApplicationClaimTypes
    {
        public const string Permission = "Permission";
        public const string ProfilePictureDataUrl = "ProfilePictureDataUrl";
    }

}
