﻿using Ica.Artemis.Application.Common.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ica.Artemis.Infrastructure.Services
{
    public class DictionaryService : IDictionaryService
    {
        private readonly IApplicationDbContext _context;

        public DictionaryService(
            IApplicationDbContext context)

        {
            _context = context;
        }
        public async Task<IDictionary<string, string>> Fetch(string name)
        {
            var result = await _context.KeyValues.Where(x => x.Name == name)
                .ToDictionaryAsync(k => k.Value, v => v.Text);
            return result;
        }
    }

}
