﻿using Ica.Artemis.Domain.Entities.Workflow;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WorkflowCore.Interface;

namespace Ica.Artemis.Application.Workflow
{
    public class DocmentApprovalWorkflow : IWorkflow<ApprovalData>
    {
        public string Id => nameof(DocmentApprovalWorkflow);

        public int Version => 1;

        public void Build(IWorkflowBuilder<ApprovalData> builder)
        {
            builder
                 .StartWith<InitialStep>()
                        .Input(step => step.To, data => data.Approver)
                        .Input(step => step.DocumentName, data => data.DocumentName)
                        .Input(step => step.DocumentId, data => data.DocumentId)
                        .Output(data => data.WorkflowId, step => step.WorkId)
                 .UserTask("Do you approve", data => data.Approver)
                     .WithOption("Approved", "I approve").Do(then => then
                         .StartWith<ApprovedStep>()
                         .Input(step => step.DocumentName, data => data.DocumentName)
                         .Input(step => step.To, data => data.Applicant)
                     )
                     .WithOption("Rejected", "I do not approve").Do(then => then
                         .StartWith<RejectedStep>()
                         .Input(step => step.DocumentName, data => data.DocumentName)
                         .Input(step => step.To, data => data.Applicant)
                     )
                     .WithEscalation(x => TimeSpan.FromMinutes(1), x => x.Applicant, action => action
                         .StartWith<CancelStep>()
                         .Input(step => step.To, data => data.Applicant)
                         .Input(step => step.DocumentName, data => data.DocumentName)
                         )

                 .Then(context => Console.WriteLine("end"));
        }
    }

}
