﻿using DocumentFormat.OpenXml.Wordprocessing;
using Hangfire.MemoryStorage.Dto;
using Ica.Artemis.Domain.Entities.Audit;
using Ica.Artemis.Domain.Entities.Log;
using Ica.Artemis.Domain.Entities.Workflow;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ica.Artemis.Application.Common.Interfaces
{
    public interface IApplicationDbContext
    {
        DbSet<Serilog> Serilogs { get; set; }
        DbSet<AuditTrail> AuditTrails { get; set; }
        DbSet<DocumentType> DocumentTypes { get; set; }
        DbSet<Document> Documents { get; set; }
        DbSet<ApprovalData> ApprovalDatas { get; set; }
        Task<int> SaveChangesAsync(CancellationToken cancellationToken);
    }
}
