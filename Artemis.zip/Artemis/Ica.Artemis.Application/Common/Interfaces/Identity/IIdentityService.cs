﻿using Ica.Artemis.Application.Common.Interfaces.Identity.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ica.Artemis.Application.Common.Interfaces.Identity
{
    public interface IIdentityService : IService
    {
        Task<Result<TokenResponseDto>> LoginAsync(TokenRequestDto request);
        Task<Result<TokenResponseDto>> RefreshTokenAsync(RefreshTokenRequestDto request);
        Task<string> GetUserNameAsync(string userId);
        Task<bool> IsInRoleAsync(string userId, string role);
        Task<bool> AuthorizeAsync(string userId, string policyName);
        Task<(Result Result, string UserId)> CreateUserAsync(string userName, string password);
        Task<Result> DeleteUserAsync(string userId);
        Task<IDictionary<string, string>> FetchUsers(string roleName);
        Task<string> UpdateLiveStatus(string userId, bool isLive);
    }
}
