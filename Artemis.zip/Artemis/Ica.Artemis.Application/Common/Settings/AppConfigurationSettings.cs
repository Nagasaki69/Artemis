﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ica.Artemis.Application.Common.Settings
{
    public class AppConfigurationSettings
    {
        public string Secret { get; set; }
        public bool BehindSSLProxy { get; set; }
        public string ProxyIP { get; set; }
        public string ApplicationUrl { get; set; }
    }

}
