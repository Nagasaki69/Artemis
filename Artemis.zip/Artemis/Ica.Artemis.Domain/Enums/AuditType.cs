﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ica.Artemis.Domain.Enums
{
    public enum AuditType
    {
        None,
        Create,
        Update,
        Delete
    }
}
