﻿


global using Ica.Artemis.Domain.Common;
global using Ica.Artemis.Domain.Entities;
global using Ica.Artemis.Domain.Enums;
global using Ica.Artemis.Domain.Exceptions;
